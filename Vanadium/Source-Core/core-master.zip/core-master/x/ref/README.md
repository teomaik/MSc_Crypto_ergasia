# Vanadium

This repository contains a reference implementation of the Vanadium APIs.

Unlike the APIs in https://github.com/vanadium/go.v23, which promises to
provide [backward compatibility] this repository makes no such promises.

[backward compatibility]: https://godoc.org/v.io/v23
