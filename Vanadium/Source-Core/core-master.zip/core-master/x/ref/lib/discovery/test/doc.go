// Copyright 2016 The Vanadium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package test contains tests that rely on a fake runtime.
//
// TODO(jhahn): Move tests to the 'discovery' directory once we support a dynamic
// runtime initialization.
package test
